package com.example.android.miwok;

import android.content.Context;

public class Word {

    private String mDefaultWord;

    private String mMiwokWord;

    private int mImageRessourceId = NO_IMAGE_PROVIDED ;

    private static final int NO_IMAGE_PROVIDED = -1;

    private int mAudioRessourceId;

    public Word(String defaultTranslation, String MiwokTranslation, int audioRessourceId){

        mDefaultWord = defaultTranslation;
        mMiwokWord = MiwokTranslation;
        mAudioRessourceId = audioRessourceId;
    }

    public Word(String defaultTranslation, String MiwokTranslation, int audioRessourceId, int ImageRessourceId){

        mDefaultWord = defaultTranslation;
        mMiwokWord = MiwokTranslation;
        mAudioRessourceId = audioRessourceId;
        mImageRessourceId = ImageRessourceId;
    }

    public String getDefaultWord(){
        return mDefaultWord;
    }

    public String getmMiwokWord(){
        return mMiwokWord;
    }

    public int getImageResourceId(){
        return mImageRessourceId;
    }

    public int getAudioRessourceId(){
        return mAudioRessourceId;
    }

    public boolean hasImage(){

        return mImageRessourceId != NO_IMAGE_PROVIDED;

    }

}
