package com.example.android.miwok;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private static final String LOG_TAG = MainActivity.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView numbers = findViewById(R.id.numbers);
        TextView colors = findViewById(R.id.colors);
        TextView family = findViewById(R.id.family);
        TextView phrases = findViewById(R.id.phrases);

        numbers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentNumbers = new Intent(MainActivity.this, NumbersActivity.class);
                startActivity(intentNumbers);
            }
        });

        colors.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentColors = new Intent(MainActivity.this, ColorsActivity.class);
                startActivity(intentColors);
            }
        });

        family.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentFamily = new Intent(MainActivity.this, FamilyMembersActivity.class);
                startActivity(intentFamily);
            }
        });

        phrases.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentPhrases = new Intent(MainActivity.this, PhrasesActivity.class);
                startActivity(intentPhrases);
            }
        });
    }

//    public void openNumbersList(View view) {
//
//        Log.d(LOG_TAG, "Button clicked!");
//
//        Intent intentNumbers = new Intent(this, NumbersActivity.class);
//        startActivity(intentNumbers);
//    }



}
